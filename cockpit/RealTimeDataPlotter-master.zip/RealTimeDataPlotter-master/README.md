# RealTimeDataPlotter
Plots realtime IMU filtered data connected to an Arduino board in communication over comport with PC
I used qcustomplot library available through www.qcustomplot.com and interfaced the library with mpu9150 IMU sensor through an arduino uno board.  This provides a direct access to a GUI standalone app communicating with Arduino in RealTime and turning the servo motor attached.
Pls watch the demo video here https://youtu.be/Yp6yDAjSesY
